oex export
==========

Generated:        2026-10-07 22:41:58 UTC
oex version:      0.4.15
Project:          https://github.com/osgeonepal/oex

Country (ISO3):   PRY
Boundary:         geoBoundaries gbOpen ADM0
Bounding box:     (-62.6446, -27.5918, -54.2589, -19.2896)

Dataset:          points_of_interest
Format:           GeoPackage (gpkg)
Features:         39,612

Source:           OpenStreetMap contributors
Source URL:       https://www.openstreetmap.org/
Snapshot:         2026-10-07
License:          Open Database License (ODC-ODbL)
License URL:      https://opendatacommons.org/licenses/odbl/1-0/

About the source
  OpenStreetMap is a community-edited geographic dataset of the world. Country
  features are extracted from the source PBF via quackosm with the union of
  all category tag filters; per-category exports apply tag predicates at query
  time.

Notes
  - GeoPackage holds all geometry types in a single .gpkg file.
  - Recommended for QGIS, ArcGIS, GDAL/OGR.

Feedback:         https://github.com/osgeonepal/oex/issues
Engine: geofabrik